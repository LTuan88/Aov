#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
	echo "Please use root privileges to execute!"
	exit 1
fi

PACKAGE_NAME="com.garena.game.kgvn"
TMP_DIR="/data/local/tmp"

GAME_ABI=$(dumpsys package "$PACKAGE_NAME" | grep "primaryCpuAbi" | awk -F '=' '{print $2}')
DEVICE_ABI=$(getprop ro.product.cpu.abi)

echo -e "\nGame ABI: $GAME_ABI"
echo "Device ABI: $DEVICE_ABI"

case $DEVICE_ABI in
	"arm64-v8a"|"armeabi-v7a")
		ABI="$GAME_ABI"
		;;
	"x86_64")
		if [[ "$GAME_ABI" == "armeabi-v7a" ]]; then
			ABI="x86"
		fi
		;;
	"x86")
		echo ""
		;;
	*)
		echo "Device ABI not supported!"
		exit 1
		;;
esac

cp -f "Injector/$ABI" "$TMP_DIR/Inject"
chmod 777 "$TMP_DIR/Inject"

cp -f "zygisk/$GAME_ABI.so" "$TMP_DIR/libTuanMeta.so"
chmod 777 "$TMP_DIR/libTuanMeta.so"

su -c "$TMP_DIR/Inject" -pkg "$PACKAGE_NAME" -lib "$TMP_DIR/libTuanMeta.so" -dl_memfd

rm -f "$TMP_DIR/Inject"
rm -f "$TMP_DIR/libTuanMeta.so"